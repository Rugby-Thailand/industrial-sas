"use client";

import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Link } from "@/i18n/navigation";
import { fgRefs, type Product } from "@/lib/convex/finishedGoodsApi";
import {
  ErrorNotice,
  Field,
  Loading,
  Status,
  measurePath,
  palletPath,
  palletDisplayStatus,
  panel,
  unitNoun,
  unitCountLabel,
  useFGText,
  useCanManage,
  useOperation,
  written,
} from "./shared";
import {
  productPalletSummary,
  summaryFormatText,
} from "./productPalletSummary";

export function ProductBatches({
  warehouseId,
  product,
}: {
  warehouseId: string;
  product: Product;
}) {
  const { tr } = useFGText();
  const canManage = useCanManage();
  const outcome = useQuery(fgRefs.listProductBatches, {
    warehouseId,
    productId: product._id,
  });
  const cancelUnit = useMutation(fgRefs.cancelLegacyUnit);
  const op = useOperation(`legacy-unit:${warehouseId}:${product._id}`);
  const [reviewId, setReviewId] = useState<string>();
  const [reason, setReason] = useState("");
  if (!outcome)
    return (
      <div className="mt-6">
        <Loading />
      </div>
    );
  if (!outcome.ok)
    return (
      <div className="mt-6">
        <ErrorNotice
          message={tr(
            "Preparation batches could not be loaded. Refresh to try again.",
            "โหลดชุดจัดเตรียมไม่สำเร็จ กรุณารีเฟรชเพื่อลองอีกครั้ง",
          )}
        />
      </div>
    );
  const { batches, legacyUnits } = outcome.value;
  const allUnits = [...batches.flatMap((entry) => entry.units), ...legacyUnits];
  const summary = productPalletSummary(
    product._id,
    allUnits,
    product.storageFormat,
  );
  const reviewUnit = legacyUnits.find((unit) => unit._id === reviewId);
  const unitLink = (unit: (typeof legacyUnits)[number]) =>
    canManage && unit.status === "AWAITING_MEASUREMENT"
      ? measurePath(unit._id)
      : palletPath(unit._id);
  const renderUnit = (unit: (typeof legacyUnits)[number], legacy = false) => (
    <li
      key={unit._id}
      className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-3"
    >
      <Link href={unitLink(unit)} className="min-w-0 hover:underline">
        <span className="font-medium">
          {unitNoun(unit.storageFormat ?? product.storageFormat, tr)} ·{" "}
          {unit.code}
        </span>
        <span className="mt-1 block text-sm text-muted">
          {unit.quantity} {product.unit} ·{" "}
          {unit.lengthMm && unit.widthMm && unit.heightMm
            ? `${unit.lengthMm / 1000} × ${unit.widthMm / 1000} × ${unit.heightMm / 1000} m`
            : tr("Awaiting measurement", "รอวัดขนาด")}
        </span>
      </Link>
      <div className="flex flex-wrap items-center gap-2">
        <Status value={palletDisplayStatus(unit)} />
        {legacy &&
          canManage &&
          ["AWAITING_MEASUREMENT", "AWAITING_PLACEMENT"].includes(
            unit.status,
          ) &&
          !unit.moveStatus && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setReviewId(unit._id);
                setReason("");
                op.setError("");
              }}
            >
              {tr("Review cancellation", "ตรวจสอบการยกเลิก")}
            </Button>
          )}
      </div>
    </li>
  );
  return (
    <section
      className="mt-6 space-y-4"
      aria-label={tr("Preparation batches", "ชุดจัดเตรียมสินค้า")}
    >
      <div>
        <h2 className="text-xl font-semibold">
          {tr("Preparation batches", "ชุดจัดเตรียมสินค้า")}
        </h2>
        <p className="mt-2 text-sm text-muted">
          {tr("Total in storage units", "สินค้าที่บันทึกในหน่วยจัดเก็บ")}:{" "}
          {summary.quantity} {product.unit} · {summaryFormatText(summary, tr)}
        </p>
      </div>
      {!batches.length && (
        <p className={`${panel} text-sm text-muted`}>
          {tr(
            "No preparation batches yet. Prepare more goods to start a new batch. Draft batches do not count as created units.",
            "ยังไม่มีชุดจัดเตรียม เลือกจัดเตรียมสินค้าเพิ่มเพื่อเริ่มชุดใหม่ ฉบับร่างไม่นับเป็นหน่วยที่สร้างแล้ว",
          )}
        </p>
      )}
      {batches.map(({ batch, units, history, editable, blockedReason }) => (
        <article key={batch._id} className={`${panel} space-y-4`}>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold">
                {tr("Batch", "ชุดจัดเตรียม")} · {batch._id.slice(-8)}
              </h3>
              <p className="mt-1 text-sm text-muted">
                {batch.totalQuantity ?? "—"} {product.unit} ·{" "}
                {batch.status === "DRAFT"
                  ? tr(
                      "Draft — no units created",
                      "ฉบับร่าง — ยังไม่สร้างหน่วยจัดเก็บ",
                    )
                  : unitCountLabel(batch.storageFormat, units.length, tr)}
                {batch.lot ? ` · ${tr("Lot", "ล็อต")} ${batch.lot}` : ""}
              </p>
            </div>
            {canManage && editable && (
              <Button asChild variant="outline">
                <Link href={`/finished-goods/batches/${batch._id}`}>
                  {batch.status === "DRAFT"
                    ? tr("Resume draft", "ทำฉบับร่างต่อ")
                    : tr("Edit packing", "แก้การแบ่งบรรจุ")}
                </Link>
              </Button>
            )}
          </div>
          {!editable && (
            <p className="text-xs text-muted">
              {blockedReason
                ? tr(
                    "This batch has reserved, moving or stored units. Resolve the affected storage work before changing its packing.",
                    "ชุดนี้มีหน่วยที่จองพื้นที่ กำลังย้าย หรือจัดเก็บแล้ว ต้องดำเนินงานจัดเก็บของหน่วยที่เกี่ยวข้องก่อนแก้การบรรจุ",
                  )
                : tr(
                    "This batch cannot currently be edited.",
                    "ขณะนี้ยังแก้ชุดนี้ไม่ได้",
                  )}
            </p>
          )}
          {history.length > 0 && (
            <details className="text-sm">
              <summary className="cursor-pointer text-muted">
                {tr("Packing history", "ประวัติการแบ่งบรรจุ")} ({history.length}
                )
              </summary>
              <ul className="mt-3 space-y-2">
                {history.map((revision) => (
                  <li
                    key={revision._id}
                    className="rounded-lg border border-border p-3"
                  >
                    {tr("Revision", "ครั้งที่")} {revision.revision} ·{" "}
                    {revision.totalQuantity ?? "—"} {product.unit} ·{" "}
                    {revision.status === "DRAFT"
                      ? tr("Draft", "ฉบับร่าง")
                      : unitCountLabel(
                          revision.storageFormat,
                          revision.palletIds.length,
                          tr,
                        )}
                    <span className="mt-1 block text-xs text-muted">
                      {revision.packages
                        .map((row) => `${row.quantity ?? "—"} ${product.unit}`)
                        .join(" + ")}
                    </span>
                  </li>
                ))}
              </ul>
            </details>
          )}
          {!!units.length && (
            <ul className="space-y-2">
              {units.map((unit) => renderUnit(unit))}
            </ul>
          )}
        </article>
      ))}
      {!!legacyUnits.length && (
        <article className={`${panel} space-y-4`}>
          <div>
            <h3 className="font-semibold">
              {tr(
                "Legacy units — no recorded batch",
                "รายการเดิม — ไม่มีข้อมูลชุด",
              )}
            </h3>
            <p className="mt-2 text-sm text-muted">
              {tr(
                "These records are shown individually. Matching SKUs do not establish that units were prepared together. Review an unused duplicate before cancelling it.",
                "แสดงรายการเดิมแยกกัน รหัสสินค้าเดียวกันไม่ได้แปลว่าจัดเตรียมพร้อมกัน ตรวจสอบรายการซ้ำที่ยังไม่ได้ใช้งานก่อนยกเลิก",
              )}
            </p>
          </div>
          <ul className="space-y-2">
            {legacyUnits.map((unit) => renderUnit(unit, true))}
          </ul>
        </article>
      )}
      <Dialog
        open={!!reviewUnit}
        onOpenChange={(open) => {
          if (!open && !op.busy) setReviewId(undefined);
        }}
      >
        <DialogContent closeLabel={tr("Close", "ปิด")}>
          <DialogHeader>
            <DialogTitle>
              {tr(
                "Review cancellation of legacy unit",
                "ตรวจสอบการยกเลิกรายการเดิม",
              )}
            </DialogTitle>
            <DialogDescription>
              {tr(
                "Cancel only an incorrect or duplicate record. The history is retained. This does not repack or reduce the contents of other units.",
                "ยกเลิกเฉพาะรายการผิดหรือซ้ำ โดยยังเก็บประวัติไว้ การยกเลิกนี้ไม่แบ่งบรรจุใหม่หรือเปลี่ยนจำนวนของหน่วยอื่น",
              )}
            </DialogDescription>
          </DialogHeader>
          {reviewUnit && (
            <>
              <p className="font-mono">{reviewUnit.code}</p>
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <dt>{tr("Before", "ก่อนยกเลิก")}</dt>
                  <dd>
                    {summary.quantity} {product.unit} · {summary.count}{" "}
                    {tr("storage units", "หน่วยจัดเก็บ")}
                  </dd>
                </div>
                <div>
                  <dt>{tr("After", "หลังยกเลิก")}</dt>
                  <dd>
                    {Math.round(
                      (summary.quantity - reviewUnit.quantity) * 1000,
                    ) / 1000}{" "}
                    {product.unit} ·{" "}
                    {unitCountLabel("OTHER", summary.count - 1, tr)}
                  </dd>
                </div>
              </dl>
              <Field
                label={tr("Cancellation reason", "เหตุผลการยกเลิก")}
                value={reason}
                onChange={setReason}
                required
                maxLength={500}
              />
              <ErrorNotice message={op.error} />
              <DialogFooter>
                <Button
                  variant="outline"
                  disabled={op.busy}
                  onClick={() => setReviewId(undefined)}
                >
                  {tr("Keep record", "เก็บรายการไว้")}
                </Button>
                <Button
                  disabled={op.busy || !reason.trim()}
                  onClick={() =>
                    void op.run(async () => {
                      const payload = {
                        warehouseId,
                        palletId: reviewUnit._id,
                        reason: reason.trim(),
                        expectedUpdatedAt: reviewUnit.updatedAt,
                      };
                      written(
                        await cancelUnit({
                          ...payload,
                          requestId: op.request(JSON.stringify(payload)),
                        }),
                      );
                      op.clearRequests();
                      setReviewId(undefined);
                    })
                  }
                >
                  {tr("Confirm cancellation", "ยืนยันยกเลิกรายการ")}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
