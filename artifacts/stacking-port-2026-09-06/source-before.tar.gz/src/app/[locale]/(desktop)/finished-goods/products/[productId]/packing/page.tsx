import { setRequestLocale } from "next-intl/server";
import { PackingScreen } from "@/features/finishedGoods/PackingScreen";

export default async function Page({
  params,
}: {
  readonly params: Promise<{ locale: string; productId: string }>;
}) {
  const { locale, productId } = await params;
  setRequestLocale(locale);
  return <PackingScreen productId={productId} />;
}
