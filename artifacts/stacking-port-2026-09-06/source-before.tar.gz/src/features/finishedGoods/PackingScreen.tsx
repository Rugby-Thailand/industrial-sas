"use client";

import { useMutation, useQuery } from "convex/react";
import { useState, type FormEvent } from "react";
import { Plus, Trash2, Copy, PackageCheck } from "lucide-react";
import { QueryGate } from "@/components/system/QueryGate";
import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/Notice";
import { Link } from "@/i18n/navigation";
import { fgRefs, type Product } from "@/lib/convex/finishedGoodsApi";
import {
  MAX_FG_PACKAGES,
  quantityPrecision,
  quantityToMinor,
  splitPackages,
  splitEqually,
  validatePacking,
  type PackedUnit,
} from "../../../convex/model/finishedGoods/packing";
import { PalletScene } from "./PalletScene";
import {
  ErrorNotice,
  Field,
  Heading,
  Loading,
  Missing,
  ViewOnlyNotice,
  FG_PATH,
  panel,
  productPath,
  storagePath,
  useCanManage,
  useDraftKey,
  useFGText,
  useOperation,
  written,
} from "./shared";

type Row = {
  id: string;
  quantity: string;
  length: string;
  width: string;
  height: string;
  weight: string;
  checked: boolean;
};
type Pending = {
  requestId: string;
  totalQuantity: number;
  packages: PackedUnit[];
};
type Draft = {
  total: string;
  capacity: string;
  count: string;
  rows: Row[];
  selected: string;
  pending?: Pending | undefined;
  completed?: readonly string[];
  recoveryBlocked?: boolean;
};
const newRow = (quantity = ""): Row => ({
  id: crypto.randomUUID(),
  quantity,
  length: "",
  width: "",
  height: "",
  weight: "",
  checked: false,
});
function initialDraft(product: Product): Draft {
  const row = newRow(String(product.defaultQuantity ?? ""));
  return {
    total: String(product.defaultQuantity ?? ""),
    capacity: String(product.defaultQuantity ?? ""),
    count: "2",
    rows: [row],
    selected: row.id,
  };
}
const toMm = (value: string) => {
  const mm = Number(value) * 1000;
  return Math.abs(mm - Math.round(mm)) < 1e-7 ? Math.round(mm) : mm;
};
const toPackage = (row: Row): PackedUnit => ({
  quantity: Number(row.quantity),
  lengthMm: toMm(row.length),
  widthMm: toMm(row.width),
  heightMm: toMm(row.height),
  ...(row.weight.trim() ? { weightKg: Number(row.weight) } : {}),
  dimensionsChecked: row.checked,
});
function readDraft(key: string, fallback: Draft): Draft {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "null");
    if (!value || typeof value !== "object") return fallback;
    const draft = value as Draft;
    const invalid = () =>
      draft.pending ? { ...fallback, recoveryBlocked: true } : fallback;
    if (
      ![draft.total, draft.capacity, draft.count, draft.selected].every(
        (v) => typeof v === "string",
      ) ||
      !Array.isArray(draft.rows) ||
      draft.rows.length > MAX_FG_PACKAGES ||
      !draft.rows.every(
        (row) =>
          row &&
          [
            row.id,
            row.quantity,
            row.length,
            row.width,
            row.height,
            row.weight,
          ].every((v) => typeof v === "string") &&
          typeof row.checked === "boolean",
      )
    )
      return invalid();
    if (new Set(draft.rows.map((r) => r.id)).size !== draft.rows.length)
      return invalid();
    if (
      draft.pending &&
      (typeof draft.pending.requestId !== "string" ||
        !/^[0-9a-f-]{36}$/.test(draft.pending.requestId) ||
        !Number.isFinite(draft.pending.totalQuantity) ||
        !Array.isArray(draft.pending.packages) ||
        !draft.pending.packages.length ||
        draft.pending.packages.length > MAX_FG_PACKAGES ||
        !draft.pending.packages.every(
          (row) =>
            row &&
            [row.quantity, row.lengthMm, row.widthMm, row.heightMm].every(
              (v) => typeof v === "number" && Number.isFinite(v),
            ) &&
            typeof row.dimensionsChecked === "boolean" &&
            (row.weightKg === undefined ||
              (typeof row.weightKg === "number" &&
                Number.isFinite(row.weightKg))),
        ))
    )
      return invalid();
    if (
      draft.completed &&
      (!Array.isArray(draft.completed) ||
        !draft.completed.every((id) => typeof id === "string"))
    )
      return fallback;
    return draft;
  } catch {
    return fallback;
  }
}
const validationMessage = (
  code: string | null,
  tr: (en: string, th: string) => string,
) => {
  switch (code) {
    case "QUANTITY_INVALID":
      return tr(
        "Enter positive quantities with the precision allowed for this unit.",
        "กรอกจำนวนที่มากกว่าศูนย์และทศนิยมที่หน่วยสินค้ารองรับ",
      );
    case "PACKAGE_COUNT_INVALID":
      return tr(
        "Add between 1 and 50 pallets.",
        "เพิ่มพาเลทระหว่าง 1 ถึง 50 พาเลท",
      );
    case "DIMENSIONS_INVALID":
      return tr(
        "Enter each pallet’s length, width and height, greater than 0 and no more than 100 m, to the nearest millimetre.",
        "กรอกความยาว ความกว้าง และความสูงทุกพาเลท มากกว่า 0 และไม่เกิน 100 ม. ละเอียดถึงมิลลิเมตร",
      );
    case "WEIGHT_INVALID":
      return tr(
        "Weight must be a positive number when supplied.",
        "น้ำหนักต้องมากกว่าศูนย์เมื่อระบุ",
      );
    case "DIMENSIONS_UNCHECKED":
      return tr(
        "Confirm the actual dimensions of every pallet, including copied dimensions.",
        "ยืนยันขนาดจริงของทุกพาเลท รวมถึงพาเลทที่คัดลอกขนาดมา",
      );
    case "QUANTITY_MISMATCH":
      return tr(
        "Allocated quantity must equal the total quantity.",
        "จำนวนที่จัดสรรต้องเท่ากับจำนวนสินค้าทั้งหมด",
      );
    default:
      return code
        ? tr(
            "Check all packing fields before continuing.",
            "ตรวจสอบข้อมูลการบรรจุก่อนดำเนินการต่อ",
          )
        : "";
  }
};

export function PackingScreen({ productId }: { productId: string }) {
  const scope = useDraftKey("fg-packing");
  if (!scope) return <Loading />;
  return (
    <QueryGate scope="WAREHOUSE">
      {(warehouseId) => (
        <PackingLoader
          key={`${scope}:${warehouseId}:${productId}`}
          scope={scope}
          warehouseId={warehouseId}
          productId={productId}
        />
      )}
    </QueryGate>
  );
}
function PackingLoader({
  scope,
  warehouseId,
  productId,
}: {
  scope: string;
  warehouseId: string;
  productId: string;
}) {
  const result = useQuery(fgRefs.getProduct, { warehouseId, productId });
  if (!result) return <Loading />;
  if (!result.ok || !result.value) return <Missing />;
  return (
    <PackingForm
      scope={scope}
      warehouseId={warehouseId}
      product={result.value}
    />
  );
}
function PackingForm({
  scope,
  warehouseId,
  product,
}: {
  scope: string;
  warehouseId: string;
  product: Product;
}) {
  const { tr, locale } = useFGText();
  const canManage = useCanManage();
  const key = `${scope}:${warehouseId}:${product._id}`;
  const op = useOperation(key);
  const createPacking = useMutation(fgRefs.createPacking);
  const [draft, setDraft] = useState(() =>
    canManage ? readDraft(key, initialDraft(product)) : initialDraft(product),
  );
  const [localError, setLocalError] = useState("");
  const [storageWarning, setStorageWarning] = useState(false);
  const [replaceQuantities, setReplaceQuantities] = useState<number[] | null>(
    null,
  );
  const selected =
    draft.rows.find((row) => row.id === draft.selected) ?? draft.rows[0];
  const packages = draft.rows.map(toPackage);
  const issue = validatePacking(Number(draft.total), packages, product.unit);
  const totalMinor = quantityToMinor(Number(draft.total), product.unit);
  const rowMinor = draft.rows.map((row) =>
    quantityToMinor(Number(row.quantity), product.unit),
  );
  const allocatedMinor = rowMinor.every((q) => q !== null)
    ? rowMinor.reduce<number>((sum, q) => sum + (q ?? 0), 0)
    : null;
  const allocated = allocatedMinor === null ? null : allocatedMinor / 1000;
  const remaining =
    totalMinor !== null && allocatedMinor !== null
      ? (totalMinor - allocatedMinor) / 1000
      : null;
  const editable =
    canManage && product.status === "ACTIVE" && !op.busy && !draft.pending;
  function persist(next: Draft, required = false) {
    try {
      localStorage.setItem(key, JSON.stringify(next));
      setStorageWarning(false);
    } catch {
      setStorageWarning(true);
      if (required) return false;
    }
    setDraft(next);
    return true;
  }
  function updateRow(id: string, changes: Partial<Row>) {
    if (!editable) return;
    setLocalError("");
    persist({
      ...draft,
      rows: draft.rows.map((row) =>
        row.id === id
          ? {
              ...row,
              ...changes,
              ...(["length", "width", "height"].some(
                (field) => field in changes,
              )
                ? { checked: false }
                : {}),
            }
          : row,
      ),
    });
  }
  function applySplit(quantities: number[]) {
    const template = selected;
    const rows = quantities.map((q) => ({
      ...newRow(String(q)),
      ...(template
        ? {
            length: template.length,
            width: template.width,
            height: template.height,
            weight: template.weight,
          }
        : {}),
    }));
    persist({ ...draft, rows, selected: rows[0]?.id ?? "" });
    setReplaceQuantities(null);
  }
  function split(mode: "capacity" | "equal") {
    const quantities =
      mode === "capacity"
        ? splitPackages(
            Number(draft.total),
            Number(draft.capacity),
            product.unit,
          )
        : splitEqually(Number(draft.total), Number(draft.count), product.unit);
    if (!quantities.length) {
      setLocalError(
        tr(
          "Enter a valid total and split value. The result must contain 1–50 non-empty pallets.",
          "กรอกจำนวนรวมและค่าที่ใช้แบ่งให้ถูกต้อง ผลลัพธ์ต้องเป็น 1–50 พาเลทที่มีสินค้า",
        ),
      );
      return;
    }
    setLocalError("");
    if (
      draft.rows.some(
        (row) => row.length || row.width || row.height || row.checked,
      ) ||
      draft.rows.length > 1
    )
      setReplaceQuantities(quantities);
    else applySplit(quantities);
  }
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!canManage || product.status !== "ACTIVE" || op.busy) return;
    if (!draft.pending && issue) {
      setLocalError(validationMessage(issue, tr));
      return;
    }
    const pending = draft.pending ?? {
      requestId: op.request(
        `packing:${JSON.stringify({ total: draft.total, packages })}`,
      ),
      totalQuantity: Number(draft.total),
      packages,
    };
    if (!draft.pending && !persist({ ...draft, pending }, true)) {
      setLocalError(
        tr(
          "Browser storage is unavailable. Enable browser storage before creating pallets so a retry after refresh cannot create duplicates.",
          "พื้นที่บันทึกในเบราว์เซอร์ไม่พร้อมใช้งาน กรุณาเปิดใช้งานก่อนสร้างพาเลทเพื่อป้องกันข้อมูลซ้ำเมื่อลองใหม่หลังรีเฟรช",
        ),
      );
      return;
    }
    const result = await op.run(async () => {
      const outcome = await createPacking({
        warehouseId,
        productId: product._id,
        ...pending,
      });
      // A definite refusal is safe to edit. An uncertain network result retains the exact request.
      if (outcome.ok && !outcome.value.written)
        persist({ ...draft, pending: undefined });
      const first = written(outcome);
      return outcome.ok && outcome.value.written
        ? outcome.value.palletIds
        : [first];
    });
    if (result) {
      persist({ ...draft, pending: undefined, completed: result });
      op.clearRequests();
      setLocalError("");
    }
  }
  if (!canManage)
    return (
      <>
        <Heading title={tr("Packing and dimensions", "การบรรจุและขนาด")} />
        <ViewOnlyNotice />
      </>
    );
  if (product.status !== "ACTIVE")
    return (
      <>
        <Heading title={tr("Packing and dimensions", "การบรรจุและขนาด")} />
        <Notice
          title={tr(
            "Activate the product before packing",
            "เปิดใช้งานสินค้าก่อนบรรจุ",
          )}
        >
          <Button asChild>
            <Link href={productPath(product._id)}>
              {tr("Edit finished good", "แก้ไขสินค้าสำเร็จรูป")}
            </Link>
          </Button>
        </Notice>
      </>
    );
  if (draft.recoveryBlocked)
    return (
      <>
        <Heading title={tr("Packing and dimensions", "การบรรจุและขนาด")} />
        <Notice
          tone="warning"
          title={tr(
            "Saved packing needs recovery",
            "ต้องกู้คืนข้อมูลการบรรจุที่บันทึกไว้",
          )}
          body={tr(
            "The saved creation request is damaged. Review existing pallets before starting another batch to avoid duplicate stock.",
            "คำขอสร้างที่บันทึกไว้เสียหาย กรุณาตรวจสอบพาเลทที่มีอยู่ก่อนเริ่มชุดใหม่เพื่อป้องกันสต็อกซ้ำ",
          )}
        >
          <Button asChild variant="outline">
            <Link href={FG_PATH}>
              {tr("Review existing pallets", "ตรวจสอบพาเลทที่มีอยู่")}
            </Link>
          </Button>
        </Notice>
      </>
    );
  if (draft.completed)
    return (
      <>
        <Heading
          title={tr("Pallets created", "สร้างพาเลทแล้ว")}
          description={`${product.sku} · ${product.name}`}
        />
        <div className={`${panel} space-y-4`}>
          <PackageCheck className="size-8 text-success" aria-hidden="true" />
          <p>
            {tr(
              "Choose an exact storage position for each pallet.",
              "เลือกตำแหน่งจัดเก็บที่แน่นอนสำหรับแต่ละพาเลท",
            )}
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            {draft.completed.map((id, i) => (
              <Button asChild variant="outline" key={id}>
                <Link href={storagePath(id)}>
                  {tr("Find storage for pallet", "เลือกที่จัดเก็บพาเลท")}{" "}
                  {i + 1}
                </Link>
              </Button>
            ))}
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild variant="outline">
              <Link href={FG_PATH}>
                {tr("Finished goods", "สินค้าสำเร็จรูป")}
              </Link>
            </Button>
            <Button onClick={() => persist(initialDraft(product))}>
              {tr("Pack another batch", "บรรจุชุดใหม่")}
            </Button>
          </div>
        </div>
      </>
    );
  return (
    <>
      <Heading
        title={tr("Packing and dimensions", "การบรรจุและขนาด")}
        description={`${product.sku} · ${product.name} · ${product.unit}`}
        back={productPath(product._id)}
      >
        {!draft.pending && (
          <Button asChild variant="outline">
            <Link href={productPath(product._id)}>
              {tr("Edit finished good", "แก้ไขสินค้าสำเร็จรูป")}
            </Link>
          </Button>
        )}
      </Heading>
      <form className="space-y-5" onSubmit={submit} noValidate>
        <ErrorNotice message={localError || op.error} />
        {storageWarning && (
          <Notice
            tone="warning"
            title={tr(
              "Draft is not saved in this browser",
              "ยังไม่ได้บันทึกฉบับร่างในเบราว์เซอร์นี้",
            )}
          />
        )}
        {draft.pending && (
          <Notice
            tone="warning"
            title={tr(
              "Confirming pallet creation",
              "กำลังตรวจสอบการสร้างพาเลท",
            )}
            body={tr(
              "Keep this packing unchanged. Retry the same request to safely retrieve the result.",
              "คงข้อมูลการบรรจุเดิมไว้ ลองคำขอเดิมอีกครั้งเพื่อตรวจสอบผลอย่างปลอดภัย",
            )}
          />
        )}
        <fieldset disabled={!editable} className="min-w-0 space-y-5">
          <div className={`${panel} grid gap-4 sm:grid-cols-2 lg:grid-cols-3`}>
            <Field
              label={tr("Total quantity", "จำนวนสินค้าทั้งหมด")}
              value={draft.total}
              onChange={(total) => persist({ ...draft, total })}
              type="number"
              min={0}
              step={quantityPrecision(product.unit) === 0 ? "1" : "0.001"}
              required
            />
            <div className="space-y-2">
              <Field
                label={tr("Quantity per pallet", "จำนวนต่อพาเลท")}
                value={draft.capacity}
                onChange={(capacity) => persist({ ...draft, capacity })}
                type="number"
                min={0}
                step="any"
              />
              <Button
                variant="outline"
                type="button"
                onClick={() => split("capacity")}
              >
                {tr("Split by quantity", "แบ่งตามจำนวนต่อพาเลท")}
              </Button>
            </div>
            <div className="space-y-2">
              <Field
                label={tr("Number of pallets", "จำนวนพาเลท")}
                value={draft.count}
                onChange={(count) => persist({ ...draft, count })}
                type="number"
                min={1}
                max={50}
                step="1"
              />
              <Button
                variant="outline"
                type="button"
                onClick={() => split("equal")}
              >
                {tr("Split equally", "แบ่งเท่า ๆ กัน")}
              </Button>
            </div>
          </div>
          {replaceQuantities && (
            <Notice
              tone="warning"
              title={tr(
                "Replace the current pallet list?",
                "แทนที่รายการพาเลทปัจจุบันหรือไม่?",
              )}
              body={tr(
                "This replaces quantities and copies the selected pallet’s dimensions. Confirm each pallet’s measurements again.",
                "รายการใหม่จะแทนที่จำนวนเดิมและคัดลอกขนาดจากพาเลทที่เลือก กรุณายืนยันขนาดแต่ละพาเลทอีกครั้ง",
              )}
            >
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  onClick={() => applySplit(replaceQuantities)}
                >
                  {tr("Replace pallets", "แทนที่พาเลท")}
                </Button>
                <Button
                  variant="outline"
                  type="button"
                  onClick={() => setReplaceQuantities(null)}
                >
                  {tr("Keep current pallets", "เก็บรายการปัจจุบัน")}
                </Button>
              </div>
            </Notice>
          )}
          <div className="grid min-w-0 items-start gap-5 xl:grid-cols-2">
            <div className="min-w-0 space-y-3">
              <div
                className="flex flex-wrap gap-2"
                aria-label={tr("Pallet selection", "เลือกพาเลท")}
              >
                {draft.rows.map((row, i) => (
                  <Button
                    type="button"
                    key={row.id}
                    variant={selected?.id === row.id ? "default" : "outline"}
                    aria-pressed={selected?.id === row.id}
                    onClick={() => persist({ ...draft, selected: row.id })}
                  >
                    {tr("Pallet", "พาเลท")} {i + 1}
                  </Button>
                ))}
              </div>
              {selected && (
                <div className={panel}>
                  {selected.length &&
                  selected.width &&
                  selected.height &&
                  Number(selected.length) > 0 &&
                  Number(selected.width) > 0 &&
                  Number(selected.height) > 0 ? (
                    <PalletScene
                      locale={locale}
                      dimensions={{
                        widthMm: Number(selected.width) * 1000,
                        depthMm: Number(selected.length) * 1000,
                        heightMm: Number(selected.height) * 1000,
                      }}
                      label={`${tr("Pallet", "พาเลท")} ${draft.rows.indexOf(selected) + 1}`}
                    />
                  ) : (
                    <div className="flex min-h-64 items-center justify-center text-center text-muted">
                      {tr(
                        "Enter length, width and height to preview this pallet.",
                        "กรอกความยาว ความกว้าง และความสูงเพื่อดูภาพพาเลท",
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="min-w-0 space-y-3">
              {selected ? (
                <section
                  className={`${panel} space-y-4`}
                  aria-label={tr("Selected pallet", "พาเลทที่เลือก")}
                >
                  <div className="flex items-center justify-between gap-2">
                    <h2 className="font-semibold">
                      {tr("Pallet", "พาเลท")} {draft.rows.indexOf(selected) + 1}
                    </h2>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={tr("Remove pallet", "ลบพาเลท")}
                      onClick={() => {
                        const rows = draft.rows.filter(
                          (r) => r.id !== selected.id,
                        );
                        persist({
                          ...draft,
                          rows,
                          selected: rows[0]?.id ?? "",
                        });
                      }}
                    >
                      <Trash2 className="size-4" aria-hidden="true" />
                    </Button>
                  </div>
                  <Field
                    label={tr("Pallet quantity", "จำนวนสินค้าในพาเลท")}
                    value={selected.quantity}
                    onChange={(quantity) =>
                      updateRow(selected.id, { quantity })
                    }
                    type="number"
                    min={0}
                    step={quantityPrecision(product.unit) === 0 ? "1" : "0.001"}
                    required
                  />
                  <div className="grid gap-4 sm:grid-cols-3">
                    {(
                      [
                        ["length", tr("Length (m)", "ความยาว (ม.)")],
                        ["width", tr("Width (m)", "ความกว้าง (ม.)")],
                        ["height", tr("Height (m)", "ความสูง (ม.)")],
                      ] as const
                    ).map(([field, label]) => (
                      <Field
                        key={field}
                        label={label}
                        value={selected[field]}
                        onChange={(value) =>
                          updateRow(selected.id, { [field]: value })
                        }
                        type="number"
                        min={0.001}
                        max={100}
                        step="0.001"
                        required
                      />
                    ))}
                  </div>
                  <Field
                    label={tr(
                      "Weight (kg, optional)",
                      "น้ำหนัก (กก., ไม่บังคับ)",
                    )}
                    value={selected.weight}
                    onChange={(weight) => updateRow(selected.id, { weight })}
                    type="number"
                    min={0}
                    step="any"
                  />
                  <label className="flex items-start gap-3 text-sm">
                    <input
                      type="checkbox"
                      className="mt-1 size-4 shrink-0 accent-accent"
                      checked={selected.checked}
                      onChange={(event) =>
                        updateRow(selected.id, {
                          checked: event.target.checked,
                        })
                      }
                    />
                    {tr(
                      "I checked this pallet’s actual outer dimensions, including its base and packaging.",
                      "ตรวจสอบขนาดภายนอกจริงของพาเลทนี้แล้ว รวมฐานและบรรจุภัณฑ์",
                    )}
                  </label>
                  <Button
                    type="button"
                    variant="outline"
                    disabled={draft.rows.length < 2}
                    onClick={() =>
                      persist({
                        ...draft,
                        rows: draft.rows.map((row) =>
                          row.id === selected.id
                            ? row
                            : {
                                ...row,
                                length: selected.length,
                                width: selected.width,
                                height: selected.height,
                                weight: selected.weight,
                                checked: false,
                              },
                        ),
                      })
                    }
                  >
                    <Copy className="size-4" aria-hidden="true" />
                    {tr(
                      "Copy dimensions to other pallets",
                      "คัดลอกขนาดไปพาเลทอื่น",
                    )}
                  </Button>
                </section>
              ) : (
                <Notice
                  title={tr("No pallets yet", "ยังไม่มีพาเลท")}
                  body={tr(
                    "Add a pallet or split the total quantity.",
                    "เพิ่มพาเลทหรือแบ่งจำนวนสินค้าทั้งหมด",
                  )}
                />
              )}
              <Button
                type="button"
                variant="outline"
                disabled={draft.rows.length >= MAX_FG_PACKAGES}
                onClick={() => {
                  const row = newRow(
                    remaining !== null && remaining > 0
                      ? String(Number(remaining.toFixed(3)))
                      : "",
                  );
                  persist({
                    ...draft,
                    rows: [...draft.rows, row],
                    selected: row.id,
                  });
                }}
              >
                <Plus className="size-4" aria-hidden="true" />
                {tr("Add pallet", "เพิ่มพาเลท")} ({draft.rows.length}/50)
              </Button>
            </div>
          </div>
          <div className={`${panel} overflow-x-auto`}>
            <table className="w-full min-w-140 text-left text-sm">
              <caption className="sr-only">
                {tr("Packing summary", "สรุปการบรรจุ")}
              </caption>
              <thead>
                <tr>
                  {[
                    tr("Pallet", "พาเลท"),
                    tr("Quantity", "จำนวน"),
                    tr("Length × width × height (m)", "ยาว × กว้าง × สูง (ม.)"),
                    tr("Dimensions", "ขนาด"),
                  ].map((label) => (
                    <th
                      key={label}
                      className="pr-4 pb-3 font-medium text-muted"
                    >
                      {label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {draft.rows.map((row, i) => (
                  <tr key={row.id} className="border-t border-border">
                    <td className="py-3 pr-4">
                      <button
                        type="button"
                        className="text-accent underline underline-offset-4"
                        onClick={() => persist({ ...draft, selected: row.id })}
                      >
                        {tr("Pallet", "พาเลท")} {i + 1}
                      </button>
                    </td>
                    <td className="py-3 pr-4">{row.quantity || "—"}</td>
                    <td className="py-3 pr-4">
                      {row.length || "—"} × {row.width || "—"} ×{" "}
                      {row.height || "—"}
                    </td>
                    <td className="py-3">
                      {row.checked
                        ? tr("Checked", "ตรวจสอบแล้ว")
                        : tr("Needs checking", "รอตรวจสอบ")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </fieldset>
        <div
          className={`${panel} flex flex-wrap items-center justify-between gap-4`}
        >
          <div aria-live="polite" className="space-y-1">
            <p>
              {tr("Allocated", "จัดสรรแล้ว")}:{" "}
              <strong>
                {allocated === null ? "—" : Number(allocated.toFixed(3))} /{" "}
                {draft.total || "—"}
              </strong>{" "}
              {product.unit}
            </p>
            <p
              className={
                remaining !== null && remaining < 0
                  ? "text-danger"
                  : "text-muted"
              }
            >
              {tr("Remaining", "คงเหลือ")}:{" "}
              {remaining === null ? "—" : Number(remaining.toFixed(3))}{" "}
              {product.unit}
            </p>
          </div>
          <Button
            type="submit"
            disabled={op.busy || (!draft.pending && Boolean(issue))}
          >
            {op.busy
              ? tr("Saving…", "กำลังบันทึก…")
              : draft.pending
                ? tr("Retry creation", "ลองสร้างอีกครั้ง")
                : tr("Create pallets", "สร้างพาเลท")}
          </Button>
          {issue && !draft.pending && (
            <p className="w-full text-sm text-muted">
              {validationMessage(issue, tr)}
            </p>
          )}
        </div>
      </form>
    </>
  );
}
