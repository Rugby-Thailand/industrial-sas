import { fireEvent, screen, waitFor, within } from "@testing-library/react";
import type { ComponentProps, ReactNode } from "react";
import { axe } from "jest-axe";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type * as ClerkModule from "@clerk/nextjs";
import type * as WorkspaceModule from "@/components/providers/WorkspaceProvider";
import type { FunctionArgs, FunctionReturnType } from "convex/server";
import type { fgRefs } from "@/lib/convex/finishedGoodsApi";
const mocks = vi.hoisted(() => ({
  canManage: true,
  actor: "user-a",
  status: "ACTIVE",
  unit: "pieces",
  create:
    vi.fn<
      (
        args: FunctionArgs<typeof fgRefs.createPacking>,
      ) => Promise<FunctionReturnType<typeof fgRefs.createPacking>>
    >(),
}));
vi.mock("@clerk/nextjs", async (importOriginal) => ({
  ...(await importOriginal<typeof ClerkModule>()),
  useAuth: () => ({ isLoaded: true, userId: mocks.actor }),
}));
vi.mock("@/components/providers/WorkspaceProvider", async (importOriginal) => ({
  ...(await importOriginal<typeof WorkspaceModule>()),
  useWorkspace: () => ({
    ...finishedGoodsWorkspace,
    navigationPermissions: mocks.canManage
      ? finishedGoodsWorkspace.navigationPermissions
      : ["masterData.storageLayout.read"],
  }),
}));
vi.mock("convex/react", () => ({
  useMutation: () => mocks.create,
  useQuery: () =>
    querySuccess({
      ...finishedGoodProduct,
      status: mocks.status,
      unit: mocks.unit,
    }),
}));
vi.mock("@/components/system/QueryGate", () => ({
  QueryGate: ({ children }: { children: (warehouseId: string) => ReactNode }) =>
    children("warehouse-a"),
}));
vi.mock("@/i18n/navigation", () => ({
  Link: ({ children, ...props }: ComponentProps<"a">) => (
    <a {...props}>{children}</a>
  ),
}));
import { renderWithIntl } from "@tests/fixtures/intl-render";
import {
  finishedGoodsWorkspace,
  finishedGoodProduct,
  querySuccess,
} from "@tests/fixtures/finished-goods-ui";
import { PackingScreen } from "./PackingScreen";
const key = "fg-packing:user-a:warehouse-a:product-a";
const show = () =>
  renderWithIntl(<PackingScreen productId="product-a" />, {
    locale: "en",
    workspace: false,
  });
function input(name: string, value: string) {
  fireEvent.change(screen.getByRole("spinbutton", { name }), {
    target: { value },
  });
}
function measure() {
  input("Length (m)", "1.001");
  input("Width (m)", "1");
  input("Height (m)", "1.4");
  fireEvent.click(screen.getByRole("checkbox"));
}
const createButton = () =>
  screen.getByRole("button", { name: "Create pallets" });
function choosePallet(number: number) {
  fireEvent.click(
    screen.getByRole("button", {
      name: `Pallet ${number}`,
      pressed: false,
    }),
  );
}
beforeEach(() => {
  localStorage.clear();
  mocks.canManage = true;
  mocks.actor = "user-a";
  mocks.status = "ACTIVE";
  mocks.unit = "pieces";
  mocks.create.mockReset();
  mocks.create.mockResolvedValue({
    ok: true,
    requestId: "test",
    value: {
      written: true,
      documentId: "pallet-a",
      palletIds: ["pallet-a", "pallet-b"],
      replayed: false,
    },
  });
});

describe("PackingScreen", () => {
  it("subtracts decimal allocation in integer units and fills the exact remainder", () => {
    mocks.unit = "kg";
    show();
    input("Total quantity", "0.3");
    input("Pallet quantity", "0.1");
    expect(screen.getByText("Remaining: 0.2 kg")).toBeVisible();
    fireEvent.click(screen.getByRole("button", { name: /Add pallet/ }));
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toHaveValue(0.2);
    expect(screen.getByText("0.3 / 0.3")).toBeVisible();
  });
  it("does not render or resend a damaged saved pending request", () => {
    const view = show();
    measure();
    view.unmount();
    const saved = JSON.parse(localStorage.getItem(key) ?? "{}");
    localStorage.setItem(
      key,
      JSON.stringify({
        ...saved,
        pending: {
          requestId: crypto.randomUUID(),
          totalQuantity: 500,
          packages: [null],
        },
      }),
    );
    show();
    expect(screen.getByText("Saved packing needs recovery")).toBeVisible();
    expect(
      screen.getByRole("link", { name: "Review existing pallets" }),
    ).toHaveAttribute("href", "/finished-goods");
    expect(
      screen.queryByRole("button", { name: "Create pallets" }),
    ).not.toBeInTheDocument();
    expect(mocks.create).not.toHaveBeenCalled();
  });
  it("keeps the editable packing form and preview accessible", async () => {
    const { container } = show();
    expect(await axe(container)).toHaveNoViolations();
    measure();
    expect(await axe(container)).toHaveNoViolations();
  });
  it("creates a checked measured pallet and exposes storage links", async () => {
    show();
    expect(createButton()).toBeDisabled();
    measure();
    expect(createButton()).toBeEnabled();
    fireEvent.click(createButton());
    await waitFor(() => expect(mocks.create).toHaveBeenCalledTimes(1));
    expect(mocks.create.mock.calls[0]?.[0]).toMatchObject({
      warehouseId: "warehouse-a",
      productId: "product-a",
      totalQuantity: 500,
      packages: [
        {
          quantity: 500,
          lengthMm: 1001,
          widthMm: 1000,
          heightMm: 1400,
          dimensionsChecked: true,
        },
      ],
    });
    expect(
      await screen.findByRole("heading", { name: "Pallets created" }),
    ).toBeVisible();
    expect(
      screen.getByRole("link", { name: "Find storage for pallet 1" }),
    ).toHaveAttribute("href", "/finished-goods/pallets/pallet-a/storage");
  });
  it("splits whole-piece quantities equally with the remainder preserved", () => {
    show();
    input("Total quantity", "1001");
    fireEvent.click(screen.getByRole("button", { name: "Split equally" }));
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toHaveValue(501);
    choosePallet(2);
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toHaveValue(500);
    expect(screen.getByText("1001 / 1001")).toBeVisible();
    expect(createButton()).toBeDisabled();
  });
  it("splits capacity with a final partial pallet and refuses oversized splits", () => {
    show();
    input("Total quantity", "1001");
    input("Quantity per pallet", "500");
    fireEvent.click(screen.getByRole("button", { name: "Split by quantity" }));
    choosePallet(3);
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toHaveValue(1);
    input("Quantity per pallet", "1");
    fireEvent.click(screen.getByRole("button", { name: "Split by quantity" }));
    expect(screen.getByRole("alert")).toHaveTextContent("1–50");
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toHaveValue(1);
  });
  it("requires a separate measurement confirmation for copied dimensions and resets it after edits", () => {
    show();
    input("Total quantity", "1000");
    fireEvent.click(screen.getByRole("button", { name: "Split by quantity" }));
    measure();
    fireEvent.click(
      screen.getByRole("button", { name: "Copy dimensions to other pallets" }),
    );
    choosePallet(2);
    expect(screen.getByRole("spinbutton", { name: "Length (m)" })).toHaveValue(
      1.001,
    );
    expect(screen.getByRole("checkbox")).not.toBeChecked();
    expect(createButton()).toBeDisabled();
    fireEvent.click(screen.getByRole("checkbox"));
    expect(createButton()).toBeEnabled();
    input("Height (m)", "1.5");
    expect(screen.getByRole("checkbox")).not.toBeChecked();
    expect(createButton()).toBeDisabled();
  });
  it("blocks over-allocation, bad dimensions, optional negative weight and fractional pieces", () => {
    show();
    measure();
    input("Pallet quantity", "501");
    expect(createButton()).toBeDisabled();
    expect(screen.getByText("Remaining: -1 pieces")).toBeVisible();
    input("Pallet quantity", "500.1");
    expect(createButton()).toBeDisabled();
    input("Pallet quantity", "500");
    input("Weight (kg, optional)", "-1");
    expect(createButton()).toBeDisabled();
    input("Weight (kg, optional)", "");
    input("Length (m)", "0.0001");
    fireEvent.click(screen.getByRole("checkbox"));
    expect(createButton()).toBeDisabled();
    expect(mocks.create).not.toHaveBeenCalled();
  });
  it("handles empty rows and adds only the remaining quantity", () => {
    show();
    fireEvent.click(screen.getByRole("button", { name: "Remove pallet" }));
    expect(screen.getByText("No pallets yet")).toBeVisible();
    expect(createButton()).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: /Add pallet/ }));
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toHaveValue(500);
  });
  it("persists draft rows and checks across refresh, private to the actor", () => {
    const view = show();
    input("Total quantity", "1000");
    measure();
    view.unmount();
    const next = show();
    expect(
      screen.getByRole("spinbutton", { name: "Total quantity" }),
    ).toHaveValue(1000);
    expect(screen.getByRole("checkbox")).toBeChecked();
    next.unmount();
    mocks.actor = "user-b";
    show();
    expect(
      screen.getByRole("spinbutton", { name: "Total quantity" }),
    ).toHaveValue(500);
    expect(screen.getByRole("checkbox")).not.toBeChecked();
  });
  it("retains the exact request after network uncertainty and refresh", async () => {
    mocks.create.mockRejectedValueOnce(new Error("offline"));
    const view = show();
    measure();
    fireEvent.click(createButton());
    await screen.findByRole("button", { name: "Retry creation" });
    await waitFor(() => expect(screen.getByRole("alert")).toBeVisible());
    const original = mocks.create.mock.calls[0]?.[0];
    expect(
      screen.getByRole("spinbutton", { name: "Pallet quantity" }),
    ).toBeDisabled();
    view.unmount();
    show();
    fireEvent.click(screen.getByRole("button", { name: "Retry creation" }));
    await screen.findByRole("heading", { name: "Pallets created" });
    expect(mocks.create.mock.calls[1]?.[0]).toEqual(original);
  });
  it("restores completion on refresh without offering to create duplicates", async () => {
    const view = show();
    measure();
    fireEvent.click(createButton());
    await screen.findByRole("heading", { name: "Pallets created" });
    view.unmount();
    show();
    expect(
      screen.getByRole("heading", { name: "Pallets created" }),
    ).toBeVisible();
    expect(
      screen.queryByRole("button", { name: "Create pallets" }),
    ).not.toBeInTheDocument();
    expect(mocks.create).toHaveBeenCalledTimes(1);
    expect(
      screen.getByRole("link", { name: "Find storage for pallet 1" }),
    ).toHaveAttribute("href", "/finished-goods/pallets/pallet-a/storage");
    expect(
      screen.getByRole("link", { name: "Find storage for pallet 2" }),
    ).toHaveAttribute("href", "/finished-goods/pallets/pallet-b/storage");
  });
  it("unlocks the draft after a definite server refusal", async () => {
    mocks.create.mockResolvedValueOnce({
      ok: true,
      requestId: "test",
      value: { written: false, error: { code: "DIMENSIONS_INVALID" } },
    });
    show();
    measure();
    fireEvent.click(createButton());
    await waitFor(() => expect(screen.getByRole("alert")).toBeVisible());
    expect(
      screen.getByRole("spinbutton", { name: "Height (m)" }),
    ).toBeEnabled();
    expect(
      JSON.parse(localStorage.getItem(key) ?? "{}").pending,
    ).toBeUndefined();
  });
  it("does not submit if a durable recovery draft cannot be saved", () => {
    const storage = vi
      .spyOn(Storage.prototype, "setItem")
      .mockImplementation(() => {
        throw new Error("quota");
      });
    show();
    measure();
    fireEvent.click(createButton());
    expect(mocks.create).not.toHaveBeenCalled();
    expect(screen.getByRole("alert")).toHaveTextContent(
      "Browser storage is unavailable",
    );
    storage.mockRestore();
  });
  it("requires confirmation before replacing measured rows", () => {
    show();
    measure();
    fireEvent.click(screen.getByRole("button", { name: "Split equally" }));
    expect(screen.getByText("Replace the current pallet list?")).toBeVisible();
    fireEvent.click(
      screen.getByRole("button", { name: "Keep current pallets" }),
    );
    expect(screen.getByRole("checkbox")).toBeChecked();
    fireEvent.click(screen.getByRole("button", { name: "Split equally" }));
    fireEvent.click(screen.getByRole("button", { name: "Replace pallets" }));
    expect(screen.getByRole("checkbox")).not.toBeChecked();
    expect(within(screen.getByRole("table")).getAllByRole("row")).toHaveLength(
      3,
    );
  });
  it("does not expose editing to read-only viewers or draft products", () => {
    mocks.canManage = false;
    const view = show();
    expect(screen.getByText("View-only access")).toBeVisible();
    expect(screen.queryByRole("spinbutton")).not.toBeInTheDocument();
    view.unmount();
    mocks.canManage = true;
    mocks.status = "DRAFT";
    show();
    expect(
      screen.getByText("Activate the product before packing"),
    ).toBeVisible();
    expect(
      screen.getByRole("link", { name: "Edit finished good" }),
    ).toHaveAttribute("href", "/finished-goods/products/product-a");
  });
});
