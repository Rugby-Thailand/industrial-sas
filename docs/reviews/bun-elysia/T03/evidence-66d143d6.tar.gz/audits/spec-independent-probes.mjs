import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdtempSync,mkdirSync,writeFileSync,symlinkSync,rmSync,readFileSync,realpathSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const wt='/Users/macbook/Development/industrial-sas-bun-security-t03-20261011';
const load=async(name)=>import(pathToFileURL(join(wt,'scripts/ci',name+'.mjs')));
const {decide,rawAuditProblems}=await load('bun-audit');
const {graphProblems,allSimplePaths,compareGraphs,overrideProblems,bunGraph,parseBunLockText}=await load('lockfile-graph');
const {compareResolutionContexts}=await load('resolution-context');
const {parseUniqueJson}=await load('json-input');
const {satisfies,compareVersions}=await load('semver-range');
const {inventoryScripts,lifecycleProblems,prepareDigest}=await load('lifecycle-policy');
const {installedGraph}=await load('installed-graph');
const integrity='sha512-'+createHash('sha512').update('independent fixture').digest('base64');
const results=[];const check=(name,fn)=>{fn();results.push({name,passed:true})};
const node=(id,name='leaf',version='1.0.0')=>({id,key:name+'@'+version,name,version,integrity,os:[],cpu:[],libc:[],registry:''});
const graph=()=>({format:'independent',problems:[],notes:[],nodes:new Map([['leaf',node('leaf')]]),edges:new Map([['leaf',[]]]),roots:[{alias:'leaf',kind:'dependencies',target:'leaf',from:null,declared:'1.0.0',declaredSource:'declared'}]});
const clean={status:0,signal:null,timedOut:false,spawnError:null,stdout:'{}',stderr:''};
for(const scope of ['app','release'])for(const mode of ['exceptions','runtime','summary']){
check(scope+'/'+mode+'/clean',()=>assert.equal(decide(mode,{child:clean,graph:graph(),coverage:[],exceptions:[],scope}).problems.length,0));
for(const defect of ['integrity','edge'])check(scope+'/'+mode+'/'+defect,()=>{const g=graph();if(defect==='integrity')g.nodes.get('leaf').integrity='wrong';else g.edges.get('leaf').push({alias:'missing',kind:'dependencies',target:'missing'});assert.ok(decide(mode,{child:clean,graph:g,coverage:[],exceptions:[],scope}).problems.length)});
}
for(const text of ['{"x":1,"x":2}','{"x":1,"\\u0078":2}','{"nested":{"x":1,"x":2}}'])check('duplicate JSON '+text,()=>assert.throws(()=>parseUniqueJson(text)));
check('valid unique nested JSON',()=>assert.deepEqual(parseUniqueJson('{"x":{"x":1},"y":["escaped\\\"",null]}'),{x:{x:1},y:['escaped"',null]}));
check('unsafe SemVer component',()=>assert.throws(()=>satisfies('9007199254740993.0.0','=9007199254740992.0.0')));
check('large numeric prerelease ordering',()=>assert.ok(compareVersions('1.0.0-9007199254740993','1.0.0-9007199254740992')>0));
check('root alias context',()=>{const a=graph(),b=graph();b.roots[0].alias='other';assert.ok(compareResolutionContexts(a,b).problems.length)});
check('edge kind context',()=>{const a=graph();a.nodes.set('host',node('host','host'));a.edges.set('host',[{alias:'leaf',kind:'dependencies',target:'leaf'}]);a.roots=[{alias:'host',kind:'dependencies',target:'host'}];const b=structuredClone(a);b.edges.get('host')[0].kind='peerDependencies';assert.ok(compareResolutionContexts(a,b).problems.length)});
check('libc loss blocks parity',()=>{const a=graph(),b=graph();a.nodes.get('leaf').libc=['glibc'];assert.ok(compareGraphs(a,b).problems.length)});
check('missing override selector provenance',()=>{const g=graph();g.roots[0].declaredSource='resolved';assert.ok(overrideProblems(g,{'leaf@^1':'1.0.0'}).problems.length)});
check('version specific production paths',()=>{const g=graph();g.nodes.set('dev',node('dev','leaf','2.0.0'));g.edges.set('dev',[]);g.roots.push({alias:'leaf',kind:'devDependencies',target:'dev'});assert.deepEqual(allSimplePaths(g,n=>n.name==='leaf'),[{path:'.>leaf',production:true,versions:['1.0.0']},{path:'.>leaf',production:false,versions:['2.0.0']}])});
check('malformed empty status1 audit',()=>assert.ok(rawAuditProblems({...clean,status:1}).length));
check('registry failure is closed',()=>assert.ok(rawAuditProblems({...clean,stderr:'error: registry request failed'}).length));
const {loadBunScope,loadPnpmScope}=await load('lockfile-graph');
const temp=realpathSync(mkdtempSync(join(tmpdir(),'t03-independent-corrected-spec-')));
const observations=[];
function fixture(scope,suffix='') {
 const root=join(temp,scope+suffix);const host=join(root,'node_modules/.bun/host@1.0.0/node_modules/host');const leaf=join(root,'node_modules/.bun/leaf@1.0.0/node_modules/leaf');
 for(const p of [host,leaf])mkdirSync(p,{recursive:true});
 writeFileSync(join(host,'package.json'),JSON.stringify({name:'host',version:'1.0.0',dependencies:{leaf:'1.0.0'}}));writeFileSync(join(leaf,'package.json'),JSON.stringify({name:'leaf',version:'1.0.0',main:'index.js'}));writeFileSync(join(leaf,'index.js'),'// Inert fixture; never execute.');
 symlinkSync(leaf,join(host,'../leaf'));symlinkSync(host,join(root,'node_modules/host'));
 const g={problems:[],nodes:new Map([['host@1.0.0',node('host@1.0.0','host')],['leaf@1.0.0',node('leaf@1.0.0')]]),edges:new Map([['host@1.0.0',[{alias:'leaf',kind:'dependencies',target:'leaf@1.0.0'}]],['leaf@1.0.0',[]]]),roots:[{alias:'host',kind:'dependencies',target:'host@1.0.0'}]};
 return {root,host,leaf,options:{expectedGraph:g,platform:{os:'darwin',cpu:'arm64'}}};
}
try {
 for(const scope of ['app','release']){
  const f=fixture(scope,'-valid');check(scope+'/valid complete store',()=>assert.equal(installedGraph(f.root,'bun',f.options).resolution.nodes.size,2));
  const original=inventoryScripts(f.root,scope,f.options);check(scope+'/empty lifecycle valid',()=>assert.equal(lifecycleProblems({inventory:original,review:{[scope]:[],prepare:{[scope]:prepareDigest(original)}},scope,trustedDependencies:[]}).length,0));
  mkdirSync(join(f.host,'node_modules/.bin'),{recursive:true});writeFileSync(join(f.host,'node_modules/.bin/shim'),'# inert shim; never execute');
  check(scope+'/.bin-only local directory allowed',()=>assert.equal(installedGraph(f.root,'bun',f.options).resolution.nodes.size,2));
  for(const type of ['materialized','scoped','deep','link','dangling','case','file','deep-link','unrelated-link','bin-directory']){
   const x=fixture(scope,'-'+type);const sub=join(x.host,'node_modules');
   if(['materialized','scoped','deep'].includes(type)) {
    const hidden=type==='materialized'?join(sub,'leaf'):type==='scoped'?join(sub,'@hidden/leaf'):join(x.host,'lib/nested/node_modules/leaf');
    mkdirSync(hidden,{recursive:true});writeFileSync(join(hidden,'package.json'),JSON.stringify({name:type==='scoped'?'@hidden/leaf':'leaf',version:'2.0.0',main:'index.js',scripts:{postinstall:'INERT_UNREVIEWED_MARKER_NEVER_EXECUTE'}}));writeFileSync(join(hidden,'index.js'),'// Never execute.');
    if(type==='materialized') {const actual=createRequire(join(x.host,'package.json')).resolve('leaf');assert.equal(actual,join(hidden,'index.js'));observations.push({scope,type,actualSelectedVersion:'2.0.0',resolveRelative:actual.slice(x.root.length+1)});}
   }else if(type==='link')symlinkSync(join(x.host,'..'),sub);
   else if(type==='dangling')symlinkSync(join(x.root,'missing'),sub);
   else if(type==='case')mkdirSync(join(x.host,'Node_Modules'),{recursive:true});
   else if(type==='file')writeFileSync(sub,'inert');
   else if(type==='deep-link'){mkdirSync(join(x.host,'lib'),{recursive:true});symlinkSync(x.leaf,join(x.host,'lib/node_modules'));}
   else if(type==='unrelated-link')symlinkSync(x.leaf,join(x.host,'lib-link'));
   else {mkdirSync(join(sub,'.bin/directory'),{recursive:true});}
   check(scope+'/'+type+'/installed fails closed',()=>assert.throws(()=>installedGraph(x.root,'bun',x.options),/unsupported nested|link inside|unknown bin/));
   check(scope+'/'+type+'/lifecycle fails closed',()=>assert.throws(()=>inventoryScripts(x.root,scope,x.options),/unsupported nested|link inside|unknown bin/));
  }
  for(const manager of ['bun','pnpm']) {
   const root=join(temp,scope+'-'+manager+'-duplicate-manifest');const dir=manager==='pnpm'&&scope==='release'?join(root,'tools/release'):root;mkdirSync(dir,{recursive:true});
   writeFileSync(join(dir,'package.json'),'{"name":"fixture","trustedDependencies":["esbuild"],"\\u0074rustedDependencies":[]}');
   if(manager==='bun')writeFileSync(join(dir,'bun.lock'),JSON.stringify({lockfileVersion:3,workspaces:{'':{name:'fixture'}},packages:{}}));
   else {writeFileSync(join(dir,'pnpm-lock.yaml'),"lockfileVersion: '9.0'\nimporters:\n  .: {}\npackages: {}\nsnapshots: {}\n");writeFileSync(join(dir,'pnpm-workspace.yaml'),'overrides: {}\n');}
   check(scope+'/'+manager+'/duplicate trust manifest refused',()=>assert.throws(()=>manager==='bun'?loadBunScope(scope,dir):loadPnpmScope(scope,root),/Duplicate JSON/));
  }
 }
}finally{rmSync(temp,{recursive:true,force:true})}
console.log(JSON.stringify({sha:'66d143d6a00f971805e1bba303014d828e9ab7e6',checks:results,nearerResolutionObservedBeforeRefusal:observations,ownedTempRemoved:true,scriptBodiesExecuted:false},null,2));
