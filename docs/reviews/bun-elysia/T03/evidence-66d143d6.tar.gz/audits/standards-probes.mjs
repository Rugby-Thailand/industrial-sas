import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {EventEmitter} from 'node:events';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
const wt='/Users/macbook/Development/industrial-sas-bun-security-t03-20261011';
const output='/Users/macbook/Development/industrial-sas-delivery-preserved-20261011/T03/final-audits/corrected-66d143d6';
const mod=async name=>import(pathToFileURL(wt+'/scripts/ci/'+name).href);
const {parseUniqueJson}=await mod('json-input.mjs');
const {parseVersion,compareVersions}=await mod('semver-range.mjs');
const {loadBunScope,loadPnpmScope,graphProblems,bunGraph,parseBunLockText}=await mod('lockfile-graph.mjs');
const {compareResolutionContexts}=await mod('resolution-context.mjs');
const {lifecycleProblems,prepareDigest}=await mod('lifecycle-policy.mjs');
const {inventoryScripts}=await mod('lifecycle-policy.mjs');
const {installedGraph}=await mod('installed-graph.mjs');
const {rawAuditProblems,decide}=await mod('bun-audit.mjs');
const results=[];
const test=async(name,body)=>{try{results.push({name,outcome:'PASSED',observed:await body()??null});}catch(e){results.push({name,outcome:'FAILED',error:e.message});}};
const integrity='sha512-'+crypto.createHash('sha512').update('inert-fixture').digest('base64');
const lock={lockfileVersion:3,workspaces:{'':{name:'fixture',dependencies:{leaf:'1.0.0'}}},packages:{leaf:['leaf@1.0.0','',{},integrity]}};
const child={status:0,signal:null,timedOut:false,spawnError:null,stdout:'{}',stderr:''};
await test('decoded duplicate JSON keys refused',()=>assert.throws(()=>parseUniqueJson('{"a":1,"\\u0061":2}'),/Duplicate/));
await test('JSON bound/depth retained',()=>{assert.throws(()=>parseUniqueJson('"'+'a'.repeat(16*1024*1024)+'"'),/bound/);assert.throws(()=>parseUniqueJson('['.repeat(130)+'0'+']'.repeat(130)),/depth/);});
await test('unsafe version and exact numeric prerelease order',()=>{assert.throws(()=>parseVersion('9007199254740993.0.0'),/Unsafe/);assert(compareVersions('1.0.0-9007199254740993','1.0.0-9007199254740992')>0);});
await test('all audit modes reject incomplete graph',()=>{const g=bunGraph(lock);g.edges.set('leaf',[{alias:'missing',kind:'dependencies',target:null}]);for(const mode of ['exceptions','runtime','summary'])assert(decide(mode,{child,graph:g,coverage:[],exceptions:[],scope:'app'}).problems.length>0);});
await test('overflow/deadline latches refuse zero child exit',()=>{assert.match(rawAuditProblems({...child,outputExceeded:true})[0],/bound/);assert.match(rawAuditProblems({...child,timedOut:true})[0],/timed out/);});
await test('lock duplicate tuple metadata schema refused',()=>{assert.throws(()=>parseBunLockText('{"packages":{},"packages":{}}'),/Duplicate/);const bad=structuredClone(lock);bad.packages.leaf[2]=[];assert(graphProblems(bunGraph(bad)).length>0);});
const contexts=(target='one')=>({nodes:new Map([['root',{key:'root@1.0.0'}],['one',{key:'leaf@1.0.0'}],['two',{key:'leaf@2.0.0'}]]),edges:new Map([['root',[{alias:'leaf',kind:'peerDependencies',target}]],['one',[]],['two',[]]]),roots:[{alias:'root',kind:'dependencies',target:'root'}]});
await test('peer binding changed refuses contextual parity',()=>assert(compareResolutionContexts(contexts(),contexts('two')).problems.length>0));
await test('explicit sharing does not allow changed root alias',()=>{const a=contexts(),b=contexts();b.roots[0].alias='changed';assert(compareResolutionContexts(a,b,{allowEquivalentSharing:true}).problems.length>0);});
await test('physical multiplicity remains strict',()=>{const a=contexts(),b=contexts();b.nodes.set('clone',{key:'leaf@1.0.0'});b.edges.set('clone',[]);assert(compareResolutionContexts(a,b).problems.length>0);assert.equal(compareResolutionContexts(a,b,{allowEquivalentSharing:true}).problems.length,0);});
const prepare={scope:'app',name:'leaf',version:'1.0.0',event:'prepare',path:'node_modules/.bun/leaf@1.0.0/node_modules/leaf/package.json',body:'echo inert',sha256:crypto.createHash('sha256').update('echo inert').digest('hex')};
await test('complete prepare digest binds path and multiplicity',()=>{const a=prepareDigest({prepare:[prepare]});assert.notEqual(a.sha256,prepareDigest({prepare:[{...prepare,path:prepare.path+'-other'}]}).sha256);assert.notEqual(a.sha256,prepareDigest({prepare:[prepare,prepare]}).sha256);});
await test('lifecycle refuses scope mutation',()=>assert(lifecycleProblems({scope:'app',inventory:{install:[],prepare:[{...prepare,scope:'release'}]},review:{app:[],prepare:{app:prepareDigest({prepare:[prepare]})}},trustedDependencies:[]}).length>0));
const fixture=path.join(output,'standards-inert-manifest');fs.mkdirSync(fixture,{recursive:true});fs.writeFileSync(path.join(fixture,'bun.lock'),JSON.stringify(lock));
await test('duplicate candidate manifest refuses trust overwrite',()=>{fs.writeFileSync(path.join(fixture,'package.json'),'{"name":"fixture","dependencies":{"leaf":"1.0.0"},"trustedDependencies":["esbuild"],"trustedDependencies":[]}');assert.throws(()=>loadBunScope('app',fixture),/Duplicate JSON/);});
const auditSource=fs.readFileSync(wt+'/scripts/ci/bun-audit.mjs','utf8');
const auditFunction=auditSource.slice(auditSource.indexOf('export function runBunAudit'),auditSource.indexOf('\nconst root =')).replace('export function','function');
function instantiate({syncSpawnThrow=false,cleanupThrow=false,creationThrow=false,unknownCodes=false}={}){
 const state={made:[],removed:[],kills:[],timers:[],clearTimers:[],spawnArgs:null};
 const child=new EventEmitter();child.stdout=new EventEmitter();child.stderr=new EventEmitter();child.kill=sig=>state.kills.push(sig);
 const context={Buffer,Promise,AUDIT_OUTPUT_LIMIT:8*1024*1024,AUDIT_TIMEOUT_MS:120000,process:{env:{PATH:'/inert'}},tmpdir:()=>'/inert',join:path.join,mkdtempSync:p=>{if(creationThrow)throw Object.assign(new Error('PRIVATE_CANARY creation'),{code:'ENOSPC'});state.made.push(p+'owned');return p+'owned';},rmSync:p=>{if(cleanupThrow)throw Object.assign(new Error('inert cleanup EACCES'),{code:unknownCodes?'PRIVATE_CANARY':'EACCES'});state.removed.push(p);},spawn:(bun,args,options)=>{state.spawnArgs={bun,args,envKeys:Object.keys(options.env)};if(syncSpawnThrow)throw Object.assign(new Error('inert host spawn EAGAIN'),{code:unknownCodes?'PRIVATE_CANARY':'EAGAIN'});return child;},setTimeout:f=>{state.timers.push(f);return 1;},clearTimeout:t=>state.clearTimers.push(t)};
 vm.createContext(context);vm.runInContext(auditFunction+';globalThis.run=runBunAudit',context);return {state,child,run:context.run};
}
await test('actual audit refactor joins split UTF8 and cleans on close',async()=>{const h=instantiate();const p=h.run('/inert/bun','/inert/project',false);h.child.stdout.emit('data',Buffer.from([0xc3]));h.child.stdout.emit('data',Buffer.from([0xa9]));h.child.emit('close',0,null);const r=await p;assert.equal(r.stdout,'é');assert.equal(h.state.removed.length,1);assert.equal(h.state.clearTimers.length,1);assert.deepEqual(h.state.spawnArgs.envKeys,['HOME','XDG_CONFIG_HOME','PATH','NO_COLOR']);return {stdout:r.stdout,cleaned:true};});
await test('actual raw cap permits exact boundary and latches excess',async()=>{const h=instantiate();const p=h.run('/inert/bun','/inert/project',false);h.child.stdout.emit('data',Buffer.alloc(8*1024*1024,32));h.child.stdout.emit('data',Buffer.from('x'));h.child.stdout.emit('data',Buffer.from('ignored'));h.child.emit('close',0,null);const r=await p;assert.equal(r.stdout.length,8*1024*1024);assert.equal(r.outputExceeded,true);assert.deepEqual(h.state.kills,['SIGKILL']);return {retainedBytes:r.stdout.length,overflow:true};});
await test('actual deadline latches zero exit and cleans',async()=>{const h=instantiate();const p=h.run('/inert/bun','/inert/project',false);h.state.timers[0]();h.child.emit('close',0,null);const r=await p;assert.equal(r.timedOut,true);assert.deepEqual(h.state.kills,['SIGKILL']);assert.equal(h.state.removed.length,1);});
await test('async spawn error remains refused with cleanup',async()=>{const h=instantiate();const p=h.run('/inert/bun','/inert/project',false);h.child.emit('error',new Error('inert ENOENT'));h.child.emit('close',-2,null);const r=await p;assert.equal(r.spawnError,'inert ENOENT');assert.equal(h.state.removed.length,1);assert(rawAuditProblems(r).length>0);});
await test('synchronous spawn exception settles sanitized refusal and cleans owned HOME',async()=>{const h=instantiate({syncSpawnThrow:true});const r=await h.run('/inert/bun','/inert/project',false);assert.equal(h.state.made.length,1);assert.equal(h.state.removed.length,1);assert.equal(r.spawnError,'synchronous spawn failure (EAGAIN)');assert.equal(r.cleanupError,null);assert(rawAuditProblems(r).length>0);});
await test('cleanup exception settles sanitized refusal including clean report',async()=>{const h=instantiate({cleanupThrow:true});const p=h.run('/inert/bun','/inert/project',false);h.child.stdout.emit('data',Buffer.from('{}'));assert.doesNotThrow(()=>h.child.emit('close',0,null));const r=await p;assert.equal(r.cleanupError,'EACCES');assert.match(rawAuditProblems(r)[0],/cleanup failed: EACCES/);assert(!JSON.stringify(r).includes('inert cleanup'));});
await test('combined unknown host codes do not leak host strings',async()=>{const h=instantiate({syncSpawnThrow:true,cleanupThrow:true,unknownCodes:true});const r=await h.run('/inert/bun','/inert/project',false);assert.equal(r.cleanupError,'unknown host error');assert.equal(r.spawnError,'synchronous spawn failure (unknown host error)');assert(!JSON.stringify(r).includes('PRIVATE_CANARY'));assert.equal(rawAuditProblems(r).length,2);});
await test('HOME creation failure rejects without owning child or cleanup',async()=>{const h=instantiate({creationThrow:true});await assert.rejects(h.run('/inert/bun','/inert/project',false),/creation/);assert.equal(h.state.made.length,0);assert.equal(h.state.spawnArgs,null);assert.equal(h.state.removed.length,0);});

const {readInstalledStore}=await mod('installed-store.mjs');
function installedFixture(manager='bun'){
 const dir=fs.mkdtempSync(path.join(output,'installed-inert-'));
 const own=(name,version='1.0.0')=>path.join(dir,'node_modules/.'+manager,name+'@'+version,'node_modules',name);
 for(const name of ['host','leaf']){fs.mkdirSync(own(name),{recursive:true});fs.writeFileSync(path.join(own(name),'package.json'),JSON.stringify({name,version:'1.0.0',...(name==='host'?{dependencies:{leaf:'*'}}:{})}));}
 fs.symlinkSync(own('leaf'),path.join(own('host'),'..','leaf'));fs.symlinkSync(own('host'),path.join(dir,'node_modules/host'));
 const graph={nodes:new Map(['host','leaf'].map(name=>[name+'@1.0.0',{id:name+'@1.0.0',key:name+'@1.0.0',name,version:'1.0.0',integrity,os:[],cpu:[],libc:[]}])),edges:new Map([['host@1.0.0',[{alias:'leaf',kind:'dependencies',target:'leaf@1.0.0'}]],['leaf@1.0.0',[]]]),roots:[{alias:'host',kind:'dependencies',target:'host@1.0.0'}],problems:[]};
 return {dir,own,host:own('host'),options:{expectedGraph:graph,platform:{os:'darwin',cpu:'arm64'}}};
}
const nestedPackage=(parent)=>{fs.mkdirSync(parent,{recursive:true});fs.writeFileSync(path.join(parent,'package.json'),JSON.stringify({name:'leaf',version:'9.0.0',scripts:{postinstall:'UNREVIEWED_INERT_NEVER_EXECUTE'}}));};
for(const manager of ['bun','pnpm'])await test(manager+' actual nearest Node nested package is refused before graph accepts',()=>{
 const f=installedFixture(manager);nestedPackage(path.join(f.host,'node_modules/leaf'));
 const nearest=createRequire(path.join(f.host,'package.json')).resolve('leaf/package.json');assert.equal(JSON.parse(fs.readFileSync(nearest,'utf8')).version,'9.0.0');
 assert.throws(()=>installedGraph(f.dir,manager,f.options),/unsupported nested node_modules/);
 if(manager==='bun')for(const scope of ['app','release'])assert.throws(()=>inventoryScripts(f.dir,scope,f.options),/unsupported nested node_modules/);
 return {actualNearestNodeVersion:'9.0.0',graphRefused:true,lifecycleBothScopesRefused:manager==='bun'};
});
const nestedVariants=[
 ['deep subdirectory',f=>nestedPackage(path.join(f.host,'lib/deeper/node_modules/leaf')),/unsupported nested node_modules/],
 ['upper casing',f=>nestedPackage(path.join(f.host,'NODE_MODULES/leaf')),/unsupported nested node_modules/],
 ['deeper mixed casing',f=>nestedPackage(path.join(f.host,'lib/Node_Modules/leaf')),/unsupported nested node_modules/],
 ['empty resolution root',f=>fs.mkdirSync(path.join(f.host,'node_modules')),/unsupported nested node_modules/],
 ['resolution root regular file',f=>fs.writeFileSync(path.join(f.host,'node_modules'),''),/unsupported nested node_modules/],
 ['outside root link',f=>{fs.mkdirSync(path.join(f.dir,'outside'));fs.symlinkSync(path.join(f.dir,'outside'),path.join(f.host,'node_modules'));},/unsupported nested node_modules/],
 ['dangling root link',f=>fs.symlinkSync(path.join(f.dir,'absent'),path.join(f.host,'node_modules')),/unsupported nested node_modules/],
 ['outside source link',f=>{fs.mkdirSync(path.join(f.dir,'outside'));fs.symlinkSync(path.join(f.dir,'outside'),path.join(f.host,'lib'));},/link inside materialized package/],
 ['source regular-file link',f=>fs.symlinkSync(path.join(f.own('leaf'),'package.json'),path.join(f.host,'linked.json')),/link inside materialized package/],
 ['package beside supported bin',f=>{fs.mkdirSync(path.join(f.host,'node_modules/.bin'),{recursive:true});nestedPackage(path.join(f.host,'node_modules/leaf'));},/unsupported nested node_modules/],
 ['linked bin directory',f=>{fs.mkdirSync(path.join(f.dir,'bins'));fs.mkdirSync(path.join(f.host,'node_modules'));fs.symlinkSync(path.join(f.dir,'bins'),path.join(f.host,'node_modules/.bin'));},/materialized directory/],
 ['scoped alias node_modules',f=>{const scope=path.join(f.host,'..','@scope');fs.mkdirSync(scope);fs.symlinkSync(f.own('leaf'),path.join(scope,'node_modules'));},/invalid alias node_modules/],
];
for(const manager of ['bun','pnpm'])for(const [name,mutate,pattern] of nestedVariants)await test(manager+' refuses '+name,()=>{const f=installedFixture(manager);mutate(f);assert.throws(()=>readInstalledStore(f.dir,manager,f.options),pattern);});
for(const manager of ['bun','pnpm'])await test(manager+' package-local bin permits shims/owned links but refuses escaping link',()=>{
 const f=installedFixture(manager),bin=path.join(f.host,'node_modules/.bin');fs.mkdirSync(bin,{recursive:true});fs.writeFileSync(path.join(bin,'shim'),'#!/bin/sh\n# INERT NEVER EXECUTE\n');fs.writeFileSync(path.join(f.own('leaf'),'cli.js'),'// inert\n');fs.symlinkSync(path.join(f.own('leaf'),'cli.js'),path.join(bin,'leaf'));
 assert.equal(readInstalledStore(f.dir,manager,f.options).entries.length,2);fs.writeFileSync(path.join(f.dir,'outside.js'),'// inert\n');fs.symlinkSync(path.join(f.dir,'outside.js'),path.join(bin,'escaped'));assert.throws(()=>readInstalledStore(f.dir,manager,f.options),/bin link escapes package ownership/);
});
await test('pnpm root metadata recognizes bounded regular files only; Bun and unknown caches refused',()=>{
 const f=installedFixture('pnpm');for(const name of ['.modules.yaml','.pnpm-workspace-state-v1.json'])fs.writeFileSync(path.join(f.dir,'node_modules',name),'{}');assert.equal(readInstalledStore(f.dir,'pnpm',f.options).entries.length,2);
 for(const mode of ['symlink','directory','oversize']){const g=installedFixture('pnpm'),file=path.join(g.dir,'node_modules/.modules.yaml');if(mode==='symlink')fs.symlinkSync(path.join(g.own('host'),'package.json'),file);else if(mode==='directory')fs.mkdirSync(file);else fs.writeFileSync(file,' '.repeat(16*1024*1024+1));assert.throws(()=>readInstalledStore(g.dir,'pnpm',g.options),/bounded regular file/);}
 const g=installedFixture('bun');fs.writeFileSync(path.join(g.dir,'node_modules/.modules.yaml'),'{}');assert.throws(()=>readInstalledStore(g.dir,'bun',g.options),/unknown root entry/);
 const h=installedFixture('pnpm');fs.mkdirSync(path.join(h.dir,'node_modules/.vite'));assert.throws(()=>readInstalledStore(h.dir,'pnpm',h.options),/unknown root entry/);
});
function manifestFixture(scope,text){
 const dir=fs.mkdtempSync(path.join(output,'manifest-inert-')),pnpmDir=scope==='app'?dir:path.join(dir,'tools/release');fs.mkdirSync(pnpmDir,{recursive:true});
 const source=scope==='app'?wt:path.join(wt,'tools/release');for(const name of ['pnpm-lock.yaml','pnpm-workspace.yaml'])fs.copyFileSync(path.join(source,name),path.join(pnpmDir,name));
 fs.writeFileSync(path.join(pnpmDir,'package.json'),text);fs.writeFileSync(path.join(pnpmDir,'bun.lock'),JSON.stringify(lock));return {dir,pnpmDir};
}
for(const scope of ['app','release'])for(const [name,text,pattern] of [
 ['literal duplicate','{"trustedDependencies":["esbuild"],"trustedDependencies":[]}',/Duplicate JSON/],
 ['decoded duplicate','{"trustedDependencies":["esbuild"],"trusted\\u0044ependencies":[]}',/Duplicate JSON/],
 ['nested duplicate','{"engines":{"node":">=24","n\\u006fde":">=0"}}',/Duplicate JSON/],
 ['null root','null',/JSON object/],['array root','[]',/JSON object/],['string root','"fixture"',/JSON object/],['number root','7',/JSON object/],['boolean root','true',/JSON object/],
 ['oversized input','{"filler":"'+'x'.repeat(16*1024*1024)+'"}',/bound/],
 ['deep input','{"filler":'+'['.repeat(130)+'0'+']'.repeat(130)+'}',/depth/]
])await test(scope+' both scope loaders refuse '+name,()=>{const f=manifestFixture(scope,text);assert.throws(()=>loadPnpmScope(scope,f.dir),pattern);assert.throws(()=>loadBunScope(scope,f.pnpmDir),pattern);});
for(const scope of ['app','release'])await test(scope+' both scope loaders keep valid unique object',()=>{const text='{"name":"fixture","trustedDependencies":[],"engines":{"node":">=24"}}',f=manifestFixture(scope,text);assert.deepEqual(loadPnpmScope(scope,f.dir).manifest,JSON.parse(text));assert.deepEqual(loadBunScope(scope,f.pnpmDir).manifest,JSON.parse(text));});
for(const [name,text,pattern] of [['decoded duplicate','{"dependencies":{"leaf":"1.0.0"},"depend\\u0065ncies":{}}',/Duplicate JSON/],['array root','[]',/JSON object/],['oversize','{"filler":"'+'x'.repeat(16*1024*1024)+'"}',/bound/]])await test('both actual CLIs refuse '+name+' before replay/network',()=>{
 const f=manifestFixture('app',text),replay=path.join(f.pnpmDir,'replay.json');fs.writeFileSync(replay,'{}');
 for(const script of ['lockfile-graph.mjs','bun-audit.mjs']){const args=['--scope=app','--bun-dir='+f.pnpmDir,...(script==='bun-audit.mjs'?['--mode=runtime','--replay='+replay+':0']:[])];const r=spawnSync(process.execPath,[path.join(wt,'scripts/ci',script),...args],{cwd:wt,encoding:'utf8',env:{NODE_ENV:'test',PATH:'/usr/bin:/bin'},timeout:15000,maxBuffer:1024*1024});assert.equal(r.signal,null);assert.equal(r.status,1);assert.match(r.stderr,pattern);assert.equal(r.stdout,'');}
});


await test('actual child invocation preserves no-env-file, production switch and isolated allowlist',async()=>{const h=instantiate();const p=h.run('/inert/bun','/inert/project',true);h.child.stdout.emit('data',Buffer.from('{}'));h.child.emit('close',0,null);assert.deepEqual(Array.from(h.state.spawnArgs.args),['--no-env-file','audit','--json','--prod']);assert.deepEqual(h.state.spawnArgs.envKeys,['HOME','XDG_CONFIG_HOME','PATH','NO_COLOR']);assert.equal((await p).cleanupError,null);});
await test('actual stderr preserves split UTF8 at exact raw-byte boundary',async()=>{const h=instantiate();const p=h.run('/inert/bun','/inert/project',false);const lead=Buffer.alloc(8*1024*1024-3,32);h.child.stderr.emit('data',lead);h.child.stderr.emit('data',Buffer.from([0xe0]));h.child.stderr.emit('data',Buffer.from([0xb8]));h.child.stderr.emit('data',Buffer.from([0x81]));h.child.emit('close',0,null);const r=await p;assert.equal(r.outputExceeded,false);assert.equal(h.state.kills.length,0);assert.equal(r.stderr.endsWith('ก'),true);assert.equal(Buffer.byteLength(r.stderr),8*1024*1024);});
await test('actual package-tree budget allows exactly the cap and refuses next entry',()=>{const source=fs.readFileSync(wt+'/scripts/ci/installed-store.mjs','utf8');const code=source.slice(source.indexOf('function packageTree('),source.indexOf('\nfunction regularMetadata('));const context={readdirSync:fs.readdirSync,join:path.join,NODE_MODULES:/^node_modules$/i,directory:p=>{assert(fs.lstatSync(p).isDirectory());assert(!fs.lstatSync(p).isSymbolicLink());}};vm.createContext(context);vm.runInContext(code+';globalThis.walk=packageTree',context);const dir=fs.mkdtempSync(path.join(output,'tree-cap-inert-'));for(const file of ['a','b','c'])fs.writeFileSync(path.join(dir,file),'');const exact={remaining:3};assert.equal(context.walk(dir,exact),null);assert.equal(exact.remaining,0);assert.throws(()=>context.walk(dir,{remaining:2}),/supported bound/);assert.match(source,/const PACKAGE_TREE_ENTRIES = 2_000_000;/);});

const report={head:'66d143d6a00f971805e1bba303014d828e9ab7e6',base:'d07f6282bfee73ac8c264f6cab4737487dc52a8e',command:process.argv.join(' '),actualSourceProbes:true,networkProvidersSecretsRealSignals:false,results,passed:results.filter(x=>x.outcome==='PASSED').length,failed:results.filter(x=>x.outcome==='FAILED').length};
fs.writeFileSync(output+'/standards-probes.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));process.exitCode=report.failed?1:0;
